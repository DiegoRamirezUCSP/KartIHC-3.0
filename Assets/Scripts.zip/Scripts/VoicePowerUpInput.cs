using System;
using System.Collections.Generic;
using UnityEngine;

#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
using UnityEngine.Windows.Speech;
#endif

public class VoicePowerUpInput : MonoBehaviour
{
    public const string VersionLabel = "VoicePowerUpInput v3 - empezar/iniciar";

    [SerializeField] private string startCommand = "empezar";
    [SerializeField] private string alternateStartCommand = "iniciar";
    [SerializeField] private string shieldCommand = "escudo";
    [SerializeField] private string boostCommand = "turbo";
    [SerializeField] private string trapCommand = "trampa";

    public event Action StartRaceRequested;
    public event Action<string> PowerUpRequested;
    public string LastPowerUp { get; private set; } = "ninguno";
    public string LastCommand { get; private set; } = "ninguno";
    public int ActivationCount { get; private set; }
    public bool SupportsKeywordRecognizer
    {
        get
        {
#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
            return true;
#else
            return false;
#endif
        }
    }

    public bool IsListening
    {
        get
        {
#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
            return keywordRecognizer != null && keywordRecognizer.IsRunning;
#else
            return false;
#endif
        }
    }

#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
    private KeywordRecognizer keywordRecognizer;
    private Dictionary<string, Action> commands;
#endif

    private void Start()
    {
        Debug.Log(VersionLabel);

#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
        commands = new Dictionary<string, Action>();
        RegisterCommand(startCommand, RequestStartRace);
        RegisterCommand(alternateStartCommand, RequestStartRace);
        RegisterCommand(shieldCommand, () => RequestPowerUp(shieldCommand));
        RegisterCommand(boostCommand, () => RequestPowerUp(boostCommand));
        RegisterCommand(trapCommand, () => RequestPowerUp(trapCommand));

        string[] keywords = new string[commands.Keys.Count];
        commands.Keys.CopyTo(keywords, 0);

        keywordRecognizer = new KeywordRecognizer(keywords);
        keywordRecognizer.OnPhraseRecognized += OnPhraseRecognized;
        keywordRecognizer.Start();
#else
        Debug.LogWarning("VoicePowerUpInput necesita un plugin o puente nativo para reconocimiento de voz en Android/iOS.");
#endif
    }

    private void Update()
    {
        // Keyboard fallback for demos and testing without microphone.
        if (WasStartPressed()) RequestStartRace();
        if (WasPressed(PowerUpKey.Shield)) RequestPowerUp(shieldCommand);
        if (WasPressed(PowerUpKey.Boost)) RequestPowerUp(boostCommand);
        if (WasPressed(PowerUpKey.Trap)) RequestPowerUp(trapCommand);
    }

#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
    private void RegisterCommand(string commandText, Action command)
    {
        if (string.IsNullOrWhiteSpace(commandText) || commands.ContainsKey(commandText))
        {
            return;
        }

        commands.Add(commandText, command);
    }

    private void OnPhraseRecognized(PhraseRecognizedEventArgs args)
    {
        if (commands.TryGetValue(args.text, out Action command))
        {
            command.Invoke();
        }
    }
#endif

    private void RequestPowerUp(string powerUpId)
    {
        LastCommand = powerUpId;
        LastPowerUp = powerUpId;
        ActivationCount++;
        Debug.Log($"Power-up solicitado: {powerUpId}");
        PowerUpRequested?.Invoke(powerUpId);
    }

    private void RequestStartRace()
    {
        LastCommand = startCommand;
        ActivationCount++;
        Debug.Log("Inicio de carrera solicitado por voz.");
        StartRaceRequested?.Invoke();
    }

    private bool WasStartPressed()
    {
#if ENABLE_INPUT_SYSTEM
        if (Keyboard.current != null)
        {
            return Keyboard.current.enterKey.wasPressedThisFrame || Keyboard.current.numpadEnterKey.wasPressedThisFrame;
        }
#endif

#if ENABLE_LEGACY_INPUT_MANAGER
        return Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter);
#else
        return false;
#endif
    }

    private bool WasPressed(PowerUpKey key)
    {
#if ENABLE_INPUT_SYSTEM
        if (Keyboard.current != null)
        {
            switch (key)
            {
                case PowerUpKey.Shield:
                    return Keyboard.current.zKey.wasPressedThisFrame;
                case PowerUpKey.Boost:
                    return Keyboard.current.xKey.wasPressedThisFrame;
                case PowerUpKey.Trap:
                    return Keyboard.current.cKey.wasPressedThisFrame;
            }
        }
#endif

#if ENABLE_LEGACY_INPUT_MANAGER
        switch (key)
        {
            case PowerUpKey.Shield:
                return Input.GetKeyDown(KeyCode.Z);
            case PowerUpKey.Boost:
                return Input.GetKeyDown(KeyCode.X);
            case PowerUpKey.Trap:
                return Input.GetKeyDown(KeyCode.C);
        }
#endif

        return false;
    }

    private enum PowerUpKey
    {
        Shield,
        Boost,
        Trap
    }

    private void OnDestroy()
    {
#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
        if (keywordRecognizer != null)
        {
            keywordRecognizer.OnPhraseRecognized -= OnPhraseRecognized;

            if (keywordRecognizer.IsRunning)
            {
                keywordRecognizer.Stop();
            }

            keywordRecognizer.Dispose();
        }
#endif
    }
}
