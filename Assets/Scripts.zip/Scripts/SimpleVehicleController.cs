using System.Collections;
using UnityEngine;

#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

[RequireComponent(typeof(Rigidbody))]
public class SimpleVehicleController : MonoBehaviour
{
    [SerializeField] private GyroSteeringInput steeringInput;
    [SerializeField] private VoicePowerUpInput voiceInput;
    [SerializeField] private DesktopPhoneControlReceiver phoneReceiver;

    [Header("Velocidad")]
    [Tooltip("Si esta activo, W/S (o flechas) controlan el auto para pruebas. Apagalo cuando conectes el control real (camara de pies).")]
    [SerializeField] private bool manualThrottle = true;
    [SerializeField] private float acceleration = 18f;
    [SerializeField] private float brakeForce = 22f;
    [SerializeField] private float turnSpeed = 95f;
    [SerializeField] private float maxSpeed = 18f;

    [Header("Estabilidad")]
    [Tooltip("Evita que el auto se incline o se voltee de costado al chocar o girar brusco.")]
    [SerializeField] private bool lockTilt = true;

    [Header("Power-up: Turbo")]
    [Tooltip("Multiplicador de aceleracion mientras el turbo esta activo.")]
    [SerializeField] private float turboAccelerationMultiplier = 2.2f;
    [Tooltip("Cuanto dura el impulso antes de volver a la velocidad normal.")]
    [SerializeField] private float turboDuration = 1.5f;

    [Header("Power-up: Escudo")]
    [Tooltip("GameObject hijo del auto con la esfera visual del escudo (empieza desactivado).")]
    [SerializeField] private GameObject shieldVisual;
    [SerializeField] private float shieldDuration = 10f;

    [Header("Power-up: Trampa")]
    [Tooltip("Prefab con el componente TrapPickup que se suelta detras del auto.")]
    [SerializeField] private GameObject trapPrefab;
    [SerializeField] private float trapDropDistance = 3f;
    [Tooltip("Cuanto dura 'frenado en seco' un auto que pisa la trampa.")]
    [SerializeField] private float trapStunDuration = 1f;

    private Rigidbody body;
    private Coroutine turboRoutine;
    private Coroutine shieldRoutine;
    private Coroutine stunRoutine;

    /// <summary>Velocidad actual en unidades/seg, expuesta para UI o diagnostico.</summary>
    public float CurrentSpeed => body != null ? body.linearVelocity.magnitude : 0f;

    /// <summary>True mientras el escudo esta activo (evita el efecto de la trampa).</summary>
    public bool IsShielded { get; private set; }

    /// <summary>True mientras el turbo esta activo.</summary>
    public bool IsTurboActive { get; private set; }

    /// <summary>True mientras esta "frenado en seco" por haber pisado una trampa.</summary>
    public bool IsStunned { get; private set; }

    /// <summary>
    /// Acelerador externo (-1..1) para conectar la camara de pies u otro
    /// sistema de input que no sea el teclado. Con manualThrottle activo,
    /// el teclado tiene prioridad (para probar sin la camara conectada).
    /// </summary>
    public float ExternalThrottle { get; set; }

    private void Awake()
    {
        body = GetComponent<Rigidbody>();
        body.interpolation = RigidbodyInterpolation.Interpolate;

        if (lockTilt)
        {
            // Solo permite rotar en Y (girar el volante). Bloquea que se incline
            // hacia adelante/atras o de costado, que es lo que hacia que la
            // camara "se disparara" al chocar o acelerar fuerte.
            body.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
        }

        if (steeringInput == null)
        {
            steeringInput = FindAnyObjectByType<GyroSteeringInput>();
        }

        if (voiceInput == null)
        {
            voiceInput = FindAnyObjectByType<VoicePowerUpInput>();
        }

        if (phoneReceiver == null)
        {
            phoneReceiver = FindAnyObjectByType<DesktopPhoneControlReceiver>();
        }

        if (shieldVisual != null)
        {
            shieldVisual.SetActive(false);
        }
    }

    private void OnEnable()
    {
        if (voiceInput != null)
        {
            voiceInput.PowerUpRequested += UsePowerUp;
        }

        if (phoneReceiver != null)
        {
            phoneReceiver.PowerUpRequested += UsePowerUp;
        }
    }

    private void OnDisable()
    {
        if (voiceInput != null)
        {
            voiceInput.PowerUpRequested -= UsePowerUp;
        }

        if (phoneReceiver != null)
        {
            phoneReceiver.PowerUpRequested -= UsePowerUp;
        }
    }

    private void FixedUpdate()
    {
        float steering = phoneReceiver != null && phoneReceiver.IsConnected
            ? phoneReceiver.Steering
            : steeringInput != null
                ? steeringInput.Steering
                : 0f;

        float throttle = IsStunned ? 0f : ReadThrottle();
        float currentAcceleration = IsTurboActive ? acceleration * turboAccelerationMultiplier : acceleration;

        if (throttle > 0f && body.linearVelocity.magnitude < maxSpeed)
        {
            body.AddForce(transform.forward * currentAcceleration * throttle, ForceMode.Acceleration);
        }
        else if (throttle < 0f)
        {
            // Frena o reversa suave.
            body.AddForce(transform.forward * brakeForce * throttle, ForceMode.Acceleration);
        }

        Quaternion rotation = Quaternion.Euler(0f, steering * turnSpeed * Time.fixedDeltaTime, 0f);
        body.MoveRotation(body.rotation * rotation);
    }

    /// <summary>
    /// Devuelve un valor -1..1: positivo acelera, negativo frena/reversa.
    /// Con manualThrottle apagado, usa ExternalThrottle (para la camara de pies).
    /// </summary>
    private float ReadThrottle()
    {
        if (manualThrottle)
        {
#if ENABLE_INPUT_SYSTEM
            if (Keyboard.current != null)
            {
                bool accelerate = Keyboard.current.wKey.isPressed || Keyboard.current.upArrowKey.isPressed;
                bool brake = Keyboard.current.sKey.isPressed || Keyboard.current.downArrowKey.isPressed;

                if (accelerate)
                {
                    return 1f;
                }

                if (brake)
                {
                    return -1f;
                }
            }
#endif
        }

        return Mathf.Clamp(ExternalThrottle, -1f, 1f);
    }

    private void UsePowerUp(string powerUpId)
    {
        switch (powerUpId)
        {
            case "turbo":
                if (turboRoutine != null)
                {
                    StopCoroutine(turboRoutine);
                }
                turboRoutine = StartCoroutine(TurboRoutine());
                break;
            case "escudo":
                if (shieldRoutine != null)
                {
                    StopCoroutine(shieldRoutine);
                }
                shieldRoutine = StartCoroutine(ShieldRoutine());
                break;
            case "trampa":
                DropTrap();
                break;
            default:
                Debug.Log($"Power-up no configurado: {powerUpId}");
                break;
        }
    }

    private IEnumerator TurboRoutine()
    {
        IsTurboActive = true;
        yield return new WaitForSeconds(turboDuration);
        IsTurboActive = false;
        turboRoutine = null;
    }

    private IEnumerator ShieldRoutine()
    {
        IsShielded = true;

        if (shieldVisual != null)
        {
            shieldVisual.SetActive(true);
        }

        yield return new WaitForSeconds(shieldDuration);

        IsShielded = false;

        if (shieldVisual != null)
        {
            shieldVisual.SetActive(false);
        }

        shieldRoutine = null;
    }

    private void DropTrap()
    {
        if (trapPrefab == null)
        {
            Debug.LogWarning("SimpleVehicleController: no hay Trap Prefab asignado.");
            return;
        }

        Vector3 dropPosition = transform.position - transform.forward * trapDropDistance;
        GameObject trapInstance = Instantiate(trapPrefab, dropPosition, Quaternion.identity);

        TrapPickup trap = trapInstance.GetComponent<TrapPickup>();
        if (trap != null)
        {
            trap.Init(this);
        }
    }

    /// <summary>
    /// Llamado por TrapPickup cuando este auto pisa una trampa. Si el escudo
    /// esta activo, no pasa nada. Si no, frena en seco por un momento.
    /// </summary>
    public void ApplyTrapEffect()
    {
        if (IsShielded)
        {
            Debug.Log("El escudo bloqueo el efecto de la trampa.");
            return;
        }

        if (stunRoutine != null)
        {
            StopCoroutine(stunRoutine);
        }
        stunRoutine = StartCoroutine(StunRoutine());
    }

    private IEnumerator StunRoutine()
    {
        IsStunned = true;
        body.linearVelocity = Vector3.zero;
        body.angularVelocity = Vector3.zero;

        yield return new WaitForSeconds(trapStunDuration);

        IsStunned = false;
        stunRoutine = null;
    }
}
