using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Stopwatch = System.Diagnostics.Stopwatch;
using UnityEngine;

/// <summary>
/// Receives leg-motion commands from the Python MediaPipe script.
/// Expected UDP messages: ACELERA, FRENA, NADA.
/// </summary>
public class LegMotionInputReceiver : MonoBehaviour
{
    [SerializeField] private int port = 5555;
    [SerializeField] private float timeoutSeconds = 1f;
    [SerializeField] private bool showDiagnostics = true;

    private UdpClient udpClient;
    private Thread receiveThread;
    private volatile bool isRunning;
    private readonly object stateLock = new object();

    private string lastCommand = "NADA";
    private string lastMessage = "sin datos";
    private double lastPacketTime;
    private float throttle;
    private float brake;

    public bool IsConnected => ReadElapsedSeconds(lastPacketTime) <= timeoutSeconds;
    public float Throttle => IsConnected ? throttle : 0f;
    public float Brake => IsConnected ? brake : 0f;
    public string LastCommand => lastCommand;
    public string LastMessage => lastMessage;

    private void OnEnable()
    {
        lastPacketTime = -timeoutSeconds;

        try
        {
            udpClient = new UdpClient(port);
        }
        catch (SocketException exception)
        {
            lastMessage = $"no se pudo abrir UDP {port}: {exception.Message}";
            Debug.LogError($"[LegMotionInputReceiver] {lastMessage}");
            return;
        }

        isRunning = true;
        receiveThread = new Thread(ReceiveLoop)
        {
            IsBackground = true,
            Name = "LegMotionInputReceiver-UDP"
        };
        receiveThread.Start();
        Debug.Log($"[LegMotionInputReceiver] Escuchando comandos de piernas en UDP {port}.");
    }

    private void ReceiveLoop()
    {
        IPEndPoint remoteEndPoint = new IPEndPoint(IPAddress.Any, port);

        while (isRunning)
        {
            try
            {
                byte[] bytes = udpClient.Receive(ref remoteEndPoint);
                string command = Encoding.UTF8.GetString(bytes).Trim();
                ApplyCommand(command, remoteEndPoint);
            }
            catch (ObjectDisposedException)
            {
                return;
            }
            catch (SocketException exception)
            {
                if (isRunning)
                {
                    lastMessage = $"error UDP: {exception.Message}";
                }
            }
        }
    }

    private void ApplyCommand(string command, IPEndPoint sender)
    {
        string normalized = command.ToUpperInvariant();

        lock (stateLock)
        {
            lastPacketTime = ReadNowSeconds();
            lastCommand = normalized;
            lastMessage = $"{sender.Address}: {normalized}";

            switch (normalized)
            {
                case "ACELERA":
                case "ACELERAR":
                    throttle = 1f;
                    brake = 0f;
                    break;
                case "FRENA":
                case "FRENAR":
                    throttle = 0f;
                    brake = 1f;
                    break;
                default:
                    throttle = 0f;
                    brake = 0f;
                    break;
            }
        }
    }

    private void OnGUI()
    {
        if (!showDiagnostics)
        {
            return;
        }

        GUILayout.BeginArea(new Rect(20, 720, 620, 135), GUI.skin.box);
        GUILayout.Label("Control por piernas / MediaPipe");
        GUILayout.Label($"Puerto UDP: {port}");
        GUILayout.Label($"Conectado: {IsConnected}");
        GUILayout.Label($"Comando: {LastCommand}");
        GUILayout.Label($"Throttle: {Throttle:0.00} | Brake: {Brake:0.00}");
        GUILayout.Label($"Ultimo mensaje: {LastMessage}");
        GUILayout.EndArea();
    }

    private void OnDisable()
    {
        isRunning = false;
        udpClient?.Close();
        receiveThread = null;
    }

    private static double ReadNowSeconds()
    {
        return (double)Stopwatch.GetTimestamp() / Stopwatch.Frequency;
    }

    private static double ReadElapsedSeconds(double startTime)
    {
        return ReadNowSeconds() - startTime;
    }
}
