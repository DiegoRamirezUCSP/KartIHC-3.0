using KartIHC.Kart;
using UnityEngine;

#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>
/// Connects the mobile/voice prototype inputs to the project's WheelCollider kart.
/// Add it to the same GameObject as KartController, or assign the references manually.
/// </summary>
[RequireComponent(typeof(KartController))]
public class KartMobileInputBridge : MonoBehaviour
{
    [Header("Targets")]
    [SerializeField] private KartController kartController;
    [SerializeField] private GyroSteeringInput gyroSteeringInput;
    [SerializeField] private JoyShockGyroSteeringInput joyShockSteeringInput;
    [SerializeField] private LegMotionInputReceiver legMotionInput;
    [SerializeField] private DesktopPhoneControlReceiver phoneReceiver;
    [SerializeField] private VoicePowerUpInput voiceInput;

    [Header("Driving")]
    [Tooltip("When enabled, the kart accelerates once the race has started. Turn it off to use W/S or arrow keys.")]
    [SerializeField] private bool autoAccelerate = true;
    [SerializeField] private float autoThrottle = 1f;
    [SerializeField] private float manualThrottle = 1f;
    [SerializeField] private float manualBrake = 1f;

    [Header("Power-ups")]
    [SerializeField] private float turboImpulse = 25f;

    private Rigidbody body;

    private void Awake()
    {
        if (kartController == null)
        {
            kartController = GetComponent<KartController>();
        }

        body = GetComponent<Rigidbody>();

        if (gyroSteeringInput == null)
        {
            gyroSteeringInput = FindFirstObjectByType<GyroSteeringInput>();
        }

        if (joyShockSteeringInput == null)
        {
            joyShockSteeringInput = FindFirstObjectByType<JoyShockGyroSteeringInput>();
        }

        if (legMotionInput == null)
        {
            legMotionInput = FindFirstObjectByType<LegMotionInputReceiver>();
        }

        if (phoneReceiver == null)
        {
            phoneReceiver = FindFirstObjectByType<DesktopPhoneControlReceiver>();
        }

        if (voiceInput == null)
        {
            voiceInput = FindFirstObjectByType<VoicePowerUpInput>();
        }
    }

    private void OnEnable()
    {
        if (voiceInput != null)
        {
            voiceInput.PowerUpRequested += UsePowerUp;
        }

        if (phoneReceiver != null)
        {
            phoneReceiver.PowerUpRequested += UsePowerUp;
        }
    }

    private void OnDisable()
    {
        if (voiceInput != null)
        {
            voiceInput.PowerUpRequested -= UsePowerUp;
        }

        if (phoneReceiver != null)
        {
            phoneReceiver.PowerUpRequested -= UsePowerUp;
        }
    }

    private void FixedUpdate()
    {
        if (kartController == null)
        {
            return;
        }

        kartController.SetSteer(ReadSteering());
        kartController.SetAccelerate(ReadThrottle());
        kartController.SetBrake(ReadBrake());
    }

    private float ReadSteering()
    {
        if (phoneReceiver != null && phoneReceiver.IsConnected)
        {
            return phoneReceiver.Steering;
        }

        if (joyShockSteeringInput != null && joyShockSteeringInput.IsConnected)
        {
            return joyShockSteeringInput.Steering;
        }

        if (gyroSteeringInput != null)
        {
            return gyroSteeringInput.Steering;
        }

        return DeviceTiltReader.ReadKeyboardAxis();
    }

    private float ReadThrottle()
    {
        if (legMotionInput != null && legMotionInput.IsConnected)
        {
            return legMotionInput.Throttle;
        }

        if (autoAccelerate)
        {
            return Mathf.Clamp01(autoThrottle);
        }

#if ENABLE_INPUT_SYSTEM
        if (Keyboard.current != null && (Keyboard.current.wKey.isPressed || Keyboard.current.upArrowKey.isPressed))
        {
            return Mathf.Clamp01(manualThrottle);
        }
#endif

#if ENABLE_LEGACY_INPUT_MANAGER
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
        {
            return Mathf.Clamp01(manualThrottle);
        }
#endif

        return 0f;
    }

    private float ReadBrake()
    {
        if (legMotionInput != null && legMotionInput.IsConnected)
        {
            return legMotionInput.Brake;
        }

        if (autoAccelerate)
        {
            return 0f;
        }

#if ENABLE_INPUT_SYSTEM
        if (Keyboard.current != null && (Keyboard.current.sKey.isPressed || Keyboard.current.downArrowKey.isPressed))
        {
            return Mathf.Clamp01(manualBrake);
        }
#endif

#if ENABLE_LEGACY_INPUT_MANAGER
        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
        {
            return Mathf.Clamp01(manualBrake);
        }
#endif

        return 0f;
    }

    private void UsePowerUp(string powerUpId)
    {
        switch (powerUpId)
        {
            case "turbo":
                if (body != null)
                {
                    body.AddForce(transform.forward * turboImpulse, ForceMode.Impulse);
                }
                break;
            case "escudo":
                Debug.Log("Escudo activado.");
                break;
            case "trampa":
                Debug.Log("Trampa lanzada.");
                break;
            default:
                Debug.Log($"Power-up no configurado: {powerUpId}");
                break;
        }
    }
}
